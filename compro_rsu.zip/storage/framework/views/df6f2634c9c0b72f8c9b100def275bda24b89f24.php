
<?php $__env->startSection('isi'); ?>

<div id="about" class="section wow fadeIn">
    <div class="container">
    <div class="heading">
        <span class="icon-logo"><img src="<?php echo e(URL::to('images/icon-logo.png')); ?>" alt="#"></span>
        <h2>Detail Berita</h2>
    </div>
    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyberita => $itemBerita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="margin: 0; padding: 10px 20px;">
        <div class="message-box">
            <h2><?php echo e($itemBerita->judul); ?></h2>
            <h4><?php echo e($itemBerita->nama_kategori); ?>, <?php echo e(date('d-m-Y, h:i:s', strtotime($itemBerita->date))); ?></h4>
        </div>
    </div>
    <div class="row">
        <!-- end col -->
        <div class="col-md-12">
        <div class="service-widget">
            <div class="post-media wow fadeIn">
                        <a href="/images/berita/<?php echo e($itemBerita->gambar); ?>" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                        <img style="
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
" src="/images/berita/<?php echo e($itemBerita->gambar); ?>" alt="" class="img-responsive">
            </div>
            </div>
            <!-- end media -->
        </div>
        <hr class="hr1"><br>
        <div class="col-md-12">
        <p><?php echo $itemBerita->isi; ?>

        </p>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\compro_rsu\resources\views/beritadetail.blade.php ENDPATH**/ ?>