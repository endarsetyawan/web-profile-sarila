
<?php $__env->startSection('isi'); ?>

    <div id="dokter" class="parallax section db" data-stellar-background-ratio="0.4" style="background:#fff;" data-scroll-id="doctors" tabindex="-1">
        <div class="container">
		
		<div class="heading">
               <span class="icon-logo"><img src="images/icon-logo.png" alt="#"></span>
               <h2>The Specialist Clinic</h2>
            </div>

            <div class="row dev-list text-center">
                <?php $__currentLoopData = $dokterprofil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keydatdok => $datdok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeIn;">
                    <div class="widget clearfix">
                        <img src="images/<?php echo e($datdok->foto); ?>" alt="" class="img-responsive img-rounded">
                        <div class="widget-title">
                            <h3 style="font-size: 16px;"><?php echo e($datdok->nama_dokter); ?></h3>
                            <small><?php echo e($datdok->nama_spesialis); ?></small>
                        </div>
                    </div><!--widget -->
                </div><!-- end col -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><!-- end row -->
                </div><!-- end container -->
    </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\compro_rsu\resources\views/datadokter.blade.php ENDPATH**/ ?>