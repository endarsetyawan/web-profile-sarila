<p>Halo, saya <?php echo e($data['nama']); ?></p>
<p>no hp saya <?php echo e($data['hp']); ?></p>
<p><?php echo e($data['pesan']); ?></p><?php /**PATH C:\xampp\htdocs\compro_rsu\resources\views/template_email.blade.php ENDPATH**/ ?>