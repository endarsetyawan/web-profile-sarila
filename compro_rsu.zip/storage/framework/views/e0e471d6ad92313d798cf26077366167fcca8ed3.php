
<?php $__env->startSection('isi'); ?>

<div id="about" class="section wow fadeIn">
    <div class="container">
    <div class="heading">
        <span class="icon-logo"><img src="<?php echo e(URL::to('images/icon-logo.png')); ?>" alt="#"></span>
        <h2>Berita <?php echo e($nama_kategori); ?></h2>
    </div>
    <!-- end title -->
    <div class="mainbar" style="
    margin: 0;
    padding: 0;
    float: left;
    width: 65%;
    ">
    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyberita => $itemBerita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="message-box">
                <h4><?php echo e($itemBerita->nama_kategori); ?></h4>
                <h5><?php echo e(date('d-m-Y, h:i:s', strtotime($itemBerita->date))); ?></h5>
                <h2><?php echo e($itemBerita->judul); ?></h2>
                <?php echo $itemBerita->isi; ?>

                <a href="/berita_detail/<?php echo e($itemBerita->id); ?>" data-scroll class="btn btn-light btn-radius btn-brd grd1 effect-1">Baca Selengkapnya</a>
            </div>
            <!-- end messagebox -->
        </div>
        <!-- end col -->
        <div class="col-md-6">
        <div class="service-widget">
            <div class="post-media wow fadeIn">
                        <a href="/images/berita/<?php echo e($itemBerita->gambar); ?>" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                        <img src="/images/berita/<?php echo e($itemBerita->gambar); ?>" alt="" class="img-responsive">
            </div>
            </div>
            <!-- end media -->
        </div>
    </div>
    <hr class="hr1">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="sidebar" style="
    padding: 0;
    float: right;
    width: 280px;
    ">
            <div class="appointment-form">
                <h3><span>+</span> Kategori Berita</h3>
                <div class="form">
                <form action="index.html">
                    <fieldset>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keykategori => $itemKategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="row">
                            <div class="form-group">
                            <hr class="hr2">
                            <a class="<?php echo e(Request::is('berita/$itemKategori->id') ? 'active' : ''); ?>" style="font-size: 25px;" href="/berita/<?php echo e($itemKategori->id); ?>"><?php echo e($itemKategori->nama_kategori); ?></a>
                            </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </fieldset>
                </form>
                </div>
            </div>
        </div>
</div>
</div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\compro_rsu\resources\views/berita.blade.php ENDPATH**/ ?>