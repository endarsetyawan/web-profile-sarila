
<?php $__env->startSection('isi'); ?>

<div id="about" class="section wow fadeIn">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/icon-logo.png" alt="#"></span>
               <h2>Jadwal Dokter</h2>
            </div>
            <!-- end title -->
            <div class="row">
            <table id="table-register" class="table table-bordered table-hover">
                <thead>
                    <tr>
                    <th>NO</th>
                    <th>Poliklinik</th>
                    <th>Nama Dokter</th>
                    <th>Hari</th>
                    <th>Waktu</th>
                    <th>Jam</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jadwaldokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyJadwal => $itemJadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style='font-size:  large;text-align: left;'><?php echo e($keyJadwal+1); ?></td>
                            <td style='font-size:  large;text-align: left;'><?php echo e($itemJadwal->nama_spesialis); ?></td>
                            <td style='font-size:  large;text-align: left;'><?php echo e($itemJadwal->nama_dokter); ?></td>
                            <td style='font-size:  large;text-align: left;'><?php echo e($itemJadwal->hari); ?></td>
                            <td style='font-size:  large;text-align: left;'><?php echo e($itemJadwal->waktu); ?></td>
                            <td style='font-size:  large;text-align: left;'><?php echo e($itemJadwal->jam); ?></td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
                <p style="text-align: center"><span style="color: #ff0000"><strong>SETIAP TANGGAL MERAH DAN HARI MINGGU TUTUP</strong></span><br />
<span style="color: #ff0000"> <strong>JADWAL SEWAKTU-WAKTU BISA BERUBAH</strong></span></p>
             </div>
         </div>
         <!-- end container -->
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\compro_rsu\resources\views/jadwal.blade.php ENDPATH**/ ?>