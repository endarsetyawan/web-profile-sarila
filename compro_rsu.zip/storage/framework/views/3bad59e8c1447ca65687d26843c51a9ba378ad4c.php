
<?php $__env->startSection('isi'); ?>
<div id="getintouch" class="section wb wow fadeIn" style="padding-bottom:0;">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/icon-logo.png" alt="#"></span>
               <h2>Kontak</h2>
            </div>
         </div>
        <div id="price" class="section pr wow fadeIn" style="background-image:url('images/price-bg.png');">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tab-content">
                            <div class="tab-pane active fade in" id="tab1">
                                <?php if($message = Session::get('success')): ?>
                                    <div class='alert alert-success alert-block'>
                                        <button type='button' class='close' data-dismiss='alert'>x</button>
                                        <strong><?php echo e($message); ?></strong>
                            </div>
                                <?php endif; ?>
                                <div class="row text-center">
                                    <form action="/send-email" method="post">
                                    <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group in_name">
                                                <input type="text" class="form-control" placeholder="Name" name='nama'  >
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group in_email">
                                                <input type="text" class="form-control" placeholder="E-mail" name='email' >
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group in_email">
                                                <input type="text" class="form-control" id="phone" placeholder="Phone" name='hp' >
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group in_email">
                                                <input type="text" class="form-control" id="subject" placeholder="Subject" name='subjek' >
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group in_message"> 
                                                <textarea class="form-control" id="message" rows="5" placeholder="Message"  name='pesan'></textarea>
                                                </div>
                                                <div class="actions">
                                                <input type="submit" value="Send Message" name="submit" id="submitButton" class="btn small" title="Submit Your Message!">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
      <footer id="footer" class="footer-area wow fadeIn">
         <div class="container">
         <?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $itemKontak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
               <div class="col-md-4">
                  <div class="logo padding">
                     <a href=""><img src="images/logo.png" alt=""></a>
                     <p><?php echo e($itemKontak->moto); ?></p>
                  </div>
               </div>
               <div class="col-md-8">
                  <div class="footer-info padding">
                     <h3>CONTACT US</h3>
                     <p><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e($itemKontak->alamat); ?></p>
                     <p><i class="fa fa-paper-plane" aria-hidden="true"></i> <?php echo e($itemKontak->email); ?></p>
                     <p><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e($itemKontak->nomer); ?></p>
                  </div>
               </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
      </footer>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\compro_rsu\resources\views/kontak.blade.php ENDPATH**/ ?>