
<?php $__env->startSection('isi'); ?>
<div class="section wow fadeIn">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/icon-logo.png" alt="#"></span>
               <h2>Total Kamar</h2>
            </div>
            <!-- end title -->
            <div class="row">
            <table id="table-register" class="table table-bordered table-hover">
                <thead>
                    <tr>
                    <th style='font-size:  large;'h>NO</th>
                    <th style='font-size:  large;'>Bangsal</th>
                    <th style='font-size:  large;'>Jumlah Bed</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $kamar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $itemKamar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style='font-size:  large;'><?php echo e($key+1); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamar->nama_bangsal); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamar->jumlah); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
             </div>
         </div>
         <!-- end container -->
      </div>
      <div class="section wow fadeIn">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/icon-logo.png" alt="#"></span>
               <h2>Kamar Anak</h2>
            </div>
            <!-- end title -->
            <div class="row">
            <table id="table-register2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                    <th style='font-size:  large;'>NO</th>
                    <th style='font-size:  large;'>Bangsal</th>
                    <th style='font-size:  large;'>Jumlah Bed</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $kamaranak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyAnak => $itemKamarAnak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style='font-size:  large;'><?php echo e($keyAnak+1); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarAnak->nama_bangsal); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarAnak->jumlah); ?></td>
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
             </div>
         </div>
         <!-- end container -->
      </div>
      
      <div class="section wow fadeIn">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/icon-logo.png" alt="#"></span>
               <h2>Kamar Kebidanan</h2>
            </div>
            <!-- end title -->
            <div class="row">
            <table id="table-register3" class="table table-bordered table-hover">
                <thead>
                    <tr>
                    <th style='font-size:  large;'>NO</th>
                    <th style='font-size:  large;'>Bangsal</th>
                    <th style='font-size:  large;'>Jumlah Bed</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $kamarbidan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyBidan => $itemKamarbidan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style='font-size:  large;'><?php echo e($keyBidan+1); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarbidan->nama_bangsal); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarbidan->jumlah); ?></td>
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
             </div>
         </div>
         <!-- end container -->
      </div>

      <div class="section wow fadeIn">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/icon-logo.png" alt="#"></span>
               <h2>Kamar ICU</h2>
            </div>
            <!-- end title -->
            <div class="row">
            <table id="table-register4" class="table table-bordered table-hover">
                <thead>
                    <tr>
                    <th style='font-size:  large;'>NO</th>
                    <th style='font-size:  large;'>Bangsal</th>
                    <th style='font-size:  large;'>Jumlah Bed</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $kamaricu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyIcu => $itemKamarIcu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style='font-size:  large;'><?php echo e($keyIcu+1); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarIcu->nama_bangsal); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarIcu->jumlah); ?></td>
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
             </div>
         </div>
         <!-- end container -->
      </div>

      <div class="section wow fadeIn">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/icon-logo.png" alt="#"></span>
               <h2>Kamar Dewasa</h2>
            </div>
            <!-- end title -->
            <div class="row">
            <table id="table-register5" class="table table-bordered table-hover">
                <thead>
                    <tr>
                    <th style='font-size:  large;'>NO</th>
                    <th style='font-size:  large;'>Bangsal</th>
                    <th style='font-size:  large;'>Jumlah Bed</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $kamardewasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyDewasa => $itemKamarDewasa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style='font-size:  large;'><?php echo e($keyDewasa+1); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarDewasa->nama_bangsal); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarDewasa->jumlah); ?></td>
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
             </div>
         </div>
         <!-- end container -->
      </div>

      <div class="section wow fadeIn">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/icon-logo.png" alt="#"></span>
               <h2>Kamar Perinatologi</h2>
            </div>
            <!-- end title -->
            <div class="row">
            <table id="table-register6" class="table table-bordered table-hover">
                <thead>
                    <tr>
                    <th style='font-size:  large;'>NO</th>
                    <th style='font-size:  large;'>Bangsal</th>
                    <th style='font-size:  large;'>Jumlah Bed</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $kamarperinatologi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyPerin => $itemKamarperin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style='font-size:  large;'><?php echo e($keyPerin+1); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarperin->nama_bangsal); ?></td>
                        <td style='font-size:  large;'><?php echo e($itemKamarperin->jumlah); ?></td>
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
             </div>
         </div>
         <!-- end container -->
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\compro_rsu\resources\views/kamar.blade.php ENDPATH**/ ?>