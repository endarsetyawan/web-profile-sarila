<p>Halo, saya {{$data['nama']}}</p>
<p>no hp saya {{$data['hp']}}</p>
<p>{{$data['pesan']}}</p>